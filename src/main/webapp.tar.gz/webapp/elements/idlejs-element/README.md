# idlejs-element

Idle.Js wrapper element

For more info see [component page](https://firmfirm.github.io/idlejs-element/).
