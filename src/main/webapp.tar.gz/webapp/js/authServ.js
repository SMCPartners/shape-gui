(function(window, undefined) {
    var authService = function() {
        var keycloak = Keycloak();

    }

})(window);
